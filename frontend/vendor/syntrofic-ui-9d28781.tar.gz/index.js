import { Fragment as e, Transition as t, computed as n, createBlock as r, createCommentVNode as i, createElementBlock as a, createElementVNode as o, createSlots as s, createTextVNode as c, createVNode as l, defineComponent as u, guardReactiveProps as d, inject as f, isRef as p, mergeModels as m, mergeProps as h, nextTick as g, normalizeProps as _, onBeforeUnmount as v, onMounted as y, openBlock as b, provide as x, ref as S, renderList as C, renderSlot as w, toDisplayString as T, unref as E, useAttrs as D, useId as O, useModel as k, useTemplateRef as A, vModelCheckbox as j, vModelDynamic as M, vModelText as N, watch as P, watchPostEffect as F, withCtx as I, withDirectives as L, withModifiers as ee } from "vue";
// src/internal/button-group.ts
var te = Symbol("Syntrofic button group"), ne = [
	"data-variant",
	"data-size",
	"type",
	"disabled",
	"aria-disabled",
	"aria-busy",
	"data-loading"
], re = { class: "sy-button__inner" }, ie = {
	key: 0,
	class: "sy-button__start"
}, ae = ["data-spinning"], R = { class: "sy-button__label" }, z = {
	key: 1,
	class: "sy-button__end"
}, B = /* @__PURE__ */ u({
	__name: "SButton",
	props: {
		variant: {},
		size: {},
		type: { default: "button" },
		disabled: { type: Boolean },
		loading: { type: Boolean }
	},
	setup(e) {
		let t = e, n = f(te, null), r = A("spinnerSlot"), s = S(t.loading);
		P(() => t.loading, async (e, t, n) => {
			if (e) {
				s.value = !0;
				return;
			}
			let i = !0;
			n(() => {
				i = !1;
			}), await g();
			let a = r.value?.getAnimations() ?? [];
			await Promise.allSettled(a.map((e) => e.finished)), i && (s.value = !1);
		});
		function c(e) {
			if (t.loading) {
				e.preventDefault(), e.stopImmediatePropagation();
				return;
			}
			let n = e.currentTarget;
			e.detail > 0 && n.ownerDocument.activeElement !== n && n.focus({ preventScroll: !0 });
		}
		return (t, l) => (b(), a("button", {
			class: "sy-button",
			"data-variant": e.variant ?? E(n)?.variant ?? "primary",
			"data-size": e.size ?? E(n)?.size ?? "md",
			type: e.type,
			disabled: e.disabled || E(n)?.disabled,
			"aria-disabled": e.loading || void 0,
			"aria-busy": e.loading || void 0,
			"data-loading": e.loading || void 0,
			onClickCapture: c
		}, [o("span", re, [
			t.$slots.start ? (b(), a("span", ie, [w(t.$slots, "start")])) : i("", !0),
			o("span", {
				ref_key: "spinnerSlot",
				ref: r,
				class: "sy-button__spinner-slot",
				"aria-hidden": "true"
			}, [o("span", {
				class: "sy-button__spinner",
				"data-spinning": s.value || void 0
			}, null, 8, ae)], 512),
			o("span", R, [w(t.$slots, "default")]),
			t.$slots.end ? (b(), a("span", z, [w(t.$slots, "end")])) : i("", !0)
		])], 40, ne));
	}
}), V = Symbol("Syntrofic field");
function H(...e) {
	return [...new Set(e.flatMap((e) => typeof e == "string" ? e.trim().split(/\s+/).filter(Boolean) : []))].join(" ") || void 0;
}
function U(e, t) {
	let r = f(V, null), i = `${t}-${O()}`, a = `${i}-hint`, o = `${i}-error`, s = D(), c = n(() => e.id ?? r?.id.value ?? i), l = n(() => e.disabled || r?.disabled.value || void 0), u = n(() => e.required || r?.required.value || void 0), d = n(() => !!(e.error || r?.invalid.value));
	function p() {
		return {
			...s,
			...d.value ? { "aria-invalid": !0 } : {},
			"aria-describedby": H(s["aria-describedby"], r?.describedBy.value, e.description && a, e.error && o)
		};
	}
	return {
		id: c,
		hintId: a,
		errorId: o,
		disabled: l,
		required: u,
		invalid: d,
		controlAttrs: p
	};
}
// src/internal/form-reset.ts
function W(e, t) {
	let n, r = !1;
	function i(n) {
		let i = e();
		i?.form && n.target === i.form && queueMicrotask(() => {
			r && !n.defaultPrevented && t();
		});
	}
	y(() => {
		r = !0, n = e()?.ownerDocument, n?.addEventListener("reset", i, !0);
	}), v(() => {
		r = !1, n?.removeEventListener("reset", i, !0);
	});
}
// \0plugin-vue:export-helper
var G = (e, t) => {
	let n = e.__vccOpts || e;
	for (let [e, r] of t) n[e] = r;
	return n;
}, K = {}, q = { class: "sy-field__label" };
function J(e, t) {
	return b(), a("label", q, [w(e.$slots, "default")]);
}
var Y = /*#__PURE__*/ G(K, [["render", J]]), oe = {}, se = { class: "sy-field__hint" };
function ce(e, t) {
	return b(), a("p", se, [w(e.$slots, "default")]);
}
var X = /*#__PURE__*/ G(oe, [["render", ce]]), le = ["role"], ue = /* @__PURE__ */ u({
	__name: "SErrorMessage",
	props: { announce: { type: Boolean } },
	setup(e) {
		return (t, n) => (b(), a("p", {
			class: "sy-field__error",
			role: e.announce ? "alert" : void 0
		}, [w(t.$slots, "default")], 8, le));
	}
}), Z = /* @__PURE__ */ u({
	__name: "SFieldError",
	setup(e) {
		return (e, t) => (b(), r(ue, null, {
			default: I(() => [w(e.$slots, "default")]),
			_: 3
		}));
	}
}), de = ["data-invalid"], fe = [
	"id",
	".defaultValue",
	"type",
	"disabled",
	"required"
], pe = /* @__PURE__ */ u({
	inheritAttrs: !1,
	__name: "SInput",
	props: /*@__PURE__*/ m({
		id: {},
		label: {},
		description: {},
		error: {},
		disabled: { type: Boolean },
		required: { type: Boolean },
		type: { default: "text" }
	}, {
		modelValue: {},
		modelModifiers: {}
	}),
	emits: ["update:modelValue"],
	setup(e, { expose: t }) {
		let n = e, s = k(e, "modelValue"), l = s.value, u = A("input"), { id: d, hintId: f, errorId: p, disabled: m, required: g, invalid: _, controlAttrs: v } = U(n, "sy-input");
		return W(() => u.value, () => {
			s.value = l;
		}), t({
			input: u,
			focus: () => u.value?.focus()
		}), (t, n) => (b(), a("div", {
			class: "sy-field",
			"data-invalid": E(_)
		}, [
			e.label ? (b(), r(Y, {
				key: 0,
				for: E(d)
			}, {
				default: I(() => [c(T(e.label), 1)]),
				_: 1
			}, 8, ["for"])) : i("", !0),
			L(o("input", h({
				ref_key: "input",
				ref: u
			}, E(v)(), {
				id: E(d),
				"onUpdate:modelValue": n[0] ||= (e) => s.value = e,
				".defaultValue": E(l) ?? "",
				class: "sy-field__control",
				"data-sy-focus-target": "",
				type: e.type,
				disabled: E(m),
				required: E(g)
			}), null, 48, fe), [[M, s.value]]),
			e.description ? (b(), r(X, {
				key: 1,
				id: E(f)
			}, {
				default: I(() => [c(T(e.description), 1)]),
				_: 1
			}, 8, ["id"])) : i("", !0),
			e.error ? (b(), r(Z, {
				key: 2,
				id: E(p)
			}, {
				default: I(() => [c(T(e.error), 1)]),
				_: 1
			}, 8, ["id"])) : i("", !0)
		], 8, de));
	}
}), me = ["data-invalid"], he = [
	"id",
	".defaultValue",
	"data-resize",
	"rows",
	"disabled",
	"required"
], ge = /* @__PURE__ */ u({
	inheritAttrs: !1,
	__name: "STextArea",
	props: /*@__PURE__*/ m({
		id: {},
		label: {},
		description: {},
		error: {},
		disabled: { type: Boolean },
		required: { type: Boolean },
		rows: { default: 3 },
		maxRows: {},
		autoGrow: { type: Boolean },
		resize: { default: "vertical" }
	}, {
		modelValue: {},
		modelModifiers: {}
	}),
	emits: ["update:modelValue"],
	setup(e, { expose: t }) {
		let n = e, s = k(e, "modelValue"), l = s.value, u = A("input"), { id: d, hintId: f, errorId: p, disabled: m, required: g, invalid: _, controlAttrs: x } = U(n, "sy-textarea"), S, C = 0, w = 0;
		function D() {
			let e = u.value;
			if (!e || (e.style.removeProperty("height"), !n.autoGrow || !e.clientWidth)) return;
			let t = getComputedStyle(e), r = e.offsetHeight, i = e.offsetHeight - e.clientHeight, a = parseFloat(t.paddingTop) + parseFloat(t.paddingBottom), o = parseFloat(t.lineHeight), s = n.maxRows && Number.isFinite(o) ? Math.max(n.maxRows, n.rows) * o + a + i : Infinity;
			e.style.height = `${Math.max(r, Math.min(e.scrollHeight + i, s))}px`;
		}
		return P([
			s,
			() => n.rows,
			() => n.maxRows,
			() => n.autoGrow
		], D, { flush: "post" }), y(() => {
			let e = u.value;
			e && typeof ResizeObserver == "function" && (w = e.clientWidth, S = new ResizeObserver(() => {
				e.clientWidth === w || C || (C = requestAnimationFrame(() => {
					C = 0, w = e.clientWidth, D();
				}));
			}), S.observe(e)), D();
		}), v(() => {
			S?.disconnect(), cancelAnimationFrame(C);
		}), W(() => u.value, () => {
			s.value = l;
		}), t({
			input: u,
			focus: () => u.value?.focus()
		}), (t, n) => (b(), a("div", {
			class: "sy-field",
			"data-invalid": E(_)
		}, [
			e.label ? (b(), r(Y, {
				key: 0,
				for: E(d)
			}, {
				default: I(() => [c(T(e.label), 1)]),
				_: 1
			}, 8, ["for"])) : i("", !0),
			L(o("textarea", h({
				ref_key: "input",
				ref: u
			}, E(x)(), {
				id: E(d),
				"onUpdate:modelValue": n[0] ||= (e) => s.value = e,
				".defaultValue": E(l) ?? "",
				class: "sy-field__control sy-textarea",
				"data-sy-focus-target": "",
				"data-resize": e.autoGrow ? "none" : e.resize,
				rows: e.rows,
				disabled: E(m),
				required: E(g)
			}), null, 48, he), [[N, s.value]]),
			e.description ? (b(), r(X, {
				key: 1,
				id: E(f)
			}, {
				default: I(() => [c(T(e.description), 1)]),
				_: 1
			}, 8, ["id"])) : i("", !0),
			e.error ? (b(), r(Z, {
				key: 2,
				id: E(p)
			}, {
				default: I(() => [c(T(e.error), 1)]),
				_: 1
			}, 8, ["id"])) : i("", !0)
		], 8, me));
	}
}), _e = Symbol("dialog-container"), Q = /* @__PURE__ */ new WeakMap();
function ve(e) {
	let t = e.documentElement, n = Q.get(e);
	return n || (n = {
		count: 0,
		overflow: t.style.overflowY,
		gutter: t.style.scrollbarGutter
	}, Q.set(e, n), t.scrollHeight > t.clientHeight && (t.style.scrollbarGutter = "stable"), t.style.overflowY = "hidden"), n.count++, () => {
		--n.count || (t.style.overflowY = n.overflow, t.style.scrollbarGutter = n.gutter, Q.delete(e));
	};
}
// src/components/SDialog.vue?vue&type=script&setup=true&lang.ts
var ye = [
	"data-size",
	"aria-labelledby",
	"aria-describedby"
], be = { class: "sy-dialog__header" }, xe = ["id"], Se = ["id"], Ce = {
	key: 0,
	class: "sy-dialog__body"
}, we = {
	key: 1,
	class: "sy-dialog__footer"
}, Te = /* @__PURE__ */ u({
	__name: "SDialog",
	props: /*@__PURE__*/ m({
		title: {},
		description: {},
		dismissLabel: { default: "Close" },
		size: { default: "sm" },
		closeOnBackdrop: {
			type: Boolean,
			default: !0
		},
		closeOnEscape: {
			type: Boolean,
			default: !0
		},
		showCloseButton: { type: Boolean }
	}, {
		open: { type: Boolean },
		openModifiers: {}
	}),
	emits: ["update:open"],
	setup(e) {
		let t = e, n = k(e, "open"), s = A("dialog");
		x(_e, s);
		let u = A("panel"), d = `sy-dialog-${O()}`, f = 0, p, m = !1;
		function h() {
			n.value = !1;
		}
		function g() {
			s.value?.open || (p?.(), p = void 0, h());
		}
		F(() => {
			let e = s.value, t = u.value, r = n.value;
			if (!e || !t) return;
			let i = ++f;
			if (r) {
				e.open || (e.showModal(), p ??= ve(e.ownerDocument), t.getBoundingClientRect()), e.dataset.visible = "";
				let r = [...e.getAnimations(), ...t.getAnimations()];
				Promise.allSettled(r.map((e) => e.finished)).then(() => {
					f === i && n.value && e.open && (e.dataset.settled = "");
				});
				return;
			}
			if (!e.open) return;
			e.hasAttribute("data-settled") && (delete e.dataset.settled, t.getBoundingClientRect()), delete e.dataset.visible;
			let a = [...e.getAnimations(), ...t.getAnimations()];
			Promise.allSettled(a.map((e) => e.finished)).then(() => {
				f === i && e.open && (e.close(), p?.(), p = void 0);
			});
		}), v(() => {
			f++, s.value?.close(), p?.(), p = void 0;
		});
		function _() {
			t.closeOnEscape && h();
		}
		function y(e) {
			let t = e.currentTarget;
			if (t !== e.target) return !1;
			let { left: n, right: r, top: i, bottom: a } = t.getBoundingClientRect();
			return e.clientX < n || e.clientX > r || e.clientY < i || e.clientY > a;
		}
		function S(e) {
			m = y(e);
		}
		function C(e) {
			t.closeOnBackdrop && m && y(e) && h(), m = !1;
		}
		function E(e) {
			if (e.key !== "Tab" || !s.value) return;
			let t = s.value, n = [...t.querySelectorAll("a[href], button, input, select, textarea, [tabindex], [contenteditable=\"true\"]")].filter((e) => e.tabIndex >= 0 && !e.matches(":disabled") && !e.closest("[inert], [hidden]") && e.getClientRects().length > 0);
			if (!n.length) {
				e.preventDefault();
				return;
			}
			let r = n[0], i = n.at(-1), a = t.ownerDocument.activeElement;
			(e.shiftKey ? a === r : a === i) && (e.preventDefault(), (e.shiftKey ? i : r)?.focus());
		}
		return (t, n) => (b(), a("dialog", {
			ref_key: "dialog",
			ref: s,
			class: "sy-dialog",
			"data-size": e.size,
			"aria-labelledby": `${d}-title`,
			"aria-describedby": e.description ? `${d}-description` : void 0,
			onCancel: ee(_, ["prevent"]),
			onClose: g,
			onPointerdown: S,
			onClick: C,
			onKeydown: E
		}, [o("div", {
			ref_key: "panel",
			ref: u,
			class: "sy-dialog__panel"
		}, [
			o("header", be, [
				o("h2", {
					id: `${d}-title`,
					class: "sy-dialog__title"
				}, T(e.title), 9, xe),
				e.showCloseButton ? (b(), r(B, {
					key: 0,
					size: "sm",
					variant: "ghost",
					onClick: h
				}, {
					default: I(() => [c(T(e.dismissLabel), 1)]),
					_: 1
				})) : i("", !0),
				e.description ? (b(), a("p", {
					key: 1,
					id: `${d}-description`,
					class: "sy-dialog__description"
				}, T(e.description), 9, Se)) : i("", !0)
			]),
			t.$slots.default ? (b(), a("div", Ce, [w(t.$slots, "default")])) : i("", !0),
			t.$slots.footer || !e.showCloseButton ? (b(), a("footer", we, [w(t.$slots, "footer", { close: h }, () => [l(B, {
				size: "sm",
				variant: "secondary",
				autofocus: "",
				onClick: h
			}, {
				default: I(() => [c(T(e.dismissLabel), 1)]),
				_: 1
			})])])) : i("", !0)
		], 512)], 40, ye));
	}
}), Ee = ["data-tone"], De = {
	key: 0,
	class: "sy-badge__dot",
	"aria-hidden": "true"
}, Oe = /* @__PURE__ */ u({
	__name: "SBadge",
	props: {
		tone: { default: "neutral" },
		dot: { type: Boolean }
	},
	setup(e) {
		return (t, n) => (b(), a("span", {
			class: "sy-badge",
			"data-tone": e.tone
		}, [e.dot ? (b(), a("span", De)) : i("", !0), w(t.$slots, "default")], 8, Ee));
	}
}), ke = ["data-tone", "role"], Ae = { class: "sy-alert__copy" }, je = { key: 0 }, Me = { key: 1 }, Ne = {
	key: 0,
	class: "sy-alert__actions"
}, Pe = /* @__PURE__ */ u({
	__name: "SAlert",
	props: {
		tone: { default: "neutral" },
		title: {},
		description: {},
		announcement: {}
	},
	setup(e) {
		return (t, n) => (b(), a("div", {
			class: "sy-alert",
			"data-tone": e.tone,
			role: e.announcement === "assertive" ? "alert" : e.announcement === "polite" ? "status" : void 0
		}, [o("div", Ae, [e.title || t.$slots.title ? (b(), a("strong", je, [w(t.$slots, "title", {}, () => [c(T(e.title), 1)])])) : i("", !0), e.description || t.$slots.default ? (b(), a("p", Me, [w(t.$slots, "default", {}, () => [c(T(e.description), 1)])])) : i("", !0)]), t.$slots.actions ? (b(), a("div", Ne, [w(t.$slots, "actions")])) : i("", !0)], 8, ke));
	}
}), Fe = Symbol("Syntrofic checkbox group"), Ie = Symbol("Syntrofic switch group");
function Le(e, t, r) {
	let i = f(e === "checkbox" ? Fe : Ie, null), a = A("input"), o = !!r.value, s = n(() => t.value === void 0 ? void 0 : String(t.value)), c = n(() => t.name ?? i?.name.value), l = n({
		get: () => i && s.value !== void 0 ? i.value.value.includes(s.value) : !!r.value,
		set(e) {
			if (!i || s.value === void 0) {
				r.value = e;
				return;
			}
			let t = new Set(i.value.value);
			e ? t.add(s.value) : t.delete(s.value), i.value.value = [...t];
		}
	}), u = n(() => i && s.value !== void 0 ? i.initial.includes(s.value) : o);
	return W(() => a.value, () => {
		i && s.value !== void 0 || (r.value = o);
	}), {
		input: a,
		name: c,
		checked: l,
		defaultChecked: u
	};
}
// src/components/SCheckbox.vue?vue&type=script&setup=true&lang.ts
var Re = { class: "sy-choice" }, ze = [
	"name",
	"value",
	".defaultChecked",
	".indeterminate"
], Be = {
	key: 0,
	class: "sy-choice__label"
}, Ve = /* @__PURE__ */ u({
	inheritAttrs: !1,
	__name: "SCheckbox",
	props: /*@__PURE__*/ m({
		indeterminate: { type: Boolean },
		value: {},
		name: {}
	}, {
		modelValue: { type: Boolean },
		modelModifiers: {}
	}),
	emits: ["update:modelValue"],
	setup(e) {
		let { input: t, checked: n, name: r, defaultChecked: s } = Le("checkbox", e, k(e, "modelValue"));
		return (c, l) => (b(), a("label", Re, [
			L(o("input", h({
				ref_key: "input",
				ref: t
			}, c.$attrs, {
				"onUpdate:modelValue": l[0] ||= (e) => p(n) ? n.value = e : null,
				class: "sy-choice__input",
				type: "checkbox",
				name: E(r),
				value: e.value ?? "on",
				".defaultChecked": E(s),
				".indeterminate": e.indeterminate
			}), null, 48, ze), [[j, E(n)]]),
			l[1] ||= o("span", {
				class: "sy-checkbox__box",
				"aria-hidden": "true"
			}, null, -1),
			c.$slots.default ? (b(), a("span", Be, [w(c.$slots, "default")])) : i("", !0)
		]));
	}
});
// src/internal/measurement.ts
function $(e, t) {
	let n = typeof e == "number" && Number.isFinite(e) ? e : 0;
	return {
		lower: n,
		upper: typeof t == "number" && Number.isFinite(t) && t > n ? t : Math.max(100, n + 1)
	};
}
function He(e, t, r) {
	let i = n(() => $(e.min, e.max)), a = n(() => {
		let { lower: n, upper: r } = i.value;
		return typeof e.value == "number" && Number.isFinite(e.value) ? Math.min(r, Math.max(n, e.value)) : t ? void 0 : n;
	}), o = n(() => {
		let { lower: e, upper: t } = i.value;
		return ((a.value ?? e) - e) / (t - e);
	}), s = n(() => new Intl.NumberFormat(e.locale ?? "en", e.formatOptions ?? (r ? {
		style: "percent",
		maximumFractionDigits: 0
	} : { maximumFractionDigits: 2 }))), c = n(() => a.value === void 0 ? "" : s.value.format(r && !e.formatOptions ? o.value : a.value));
	return {
		value: a,
		display: c,
		bars: n(() => ({
			"--sy-measure-percent": `${o.value * 100}%`,
			"--sy-arc-target": o.value
		})),
		aria: n(() => ({
			"aria-valuemin": i.value.lower,
			"aria-valuemax": i.value.upper,
			"aria-valuenow": a.value,
			"aria-valuetext": c.value || void 0
		}))
	};
}
// src/components/SMotionText.vue?vue&type=script&setup=true&lang.ts
var Ue = { class: "sy-motion-text" }, We = ["aria-live"], Ge = {
	class: "sy-motion-text__visual",
	"aria-hidden": "true"
}, Ke = ["dir"], qe = ["data-motion", "data-number-sign"], Je = /* @__PURE__ */ u({
	__name: "SMotionText",
	props: {
		value: {},
		motion: { default: "reveal" },
		announce: { type: Boolean },
		appear: { type: Boolean }
	},
	setup(r) {
		let i = r, s = typeof Intl.Segmenter == "function" ? new Intl.Segmenter(void 0, { granularity: "grapheme" }) : void 0, c = [], u = [], d = 0, f = /^\p{Decimal_Number}$/u, p = /^[+\-\u2212]$/u, m = /^[\p{Script=Arabic}\p{Script=Syriac}\p{Script=Mandaic}]/u;
		function h(e) {
			let t = s ? Array.from(s.segment(e), (e) => e.segment) : Array.from(e), n = [], r = !1;
			for (let e of t) {
				let t = m.test(e) && /\p{Letter}/u.test(e);
				r && t ? n[n.length - 1] += e : n.push(e), r = t;
			}
			return n;
		}
		let g = n(() => h(i.value)), _ = n(() => {
			let e = [];
			for (let [t, n] of g.value.entries()) {
				let r = f.test(n), a = /^[.,\u066b\u066c]$/u.test(n) && f.test(g.value[t - 1] ?? "") && f.test(g.value[t + 1] ?? ""), o = r || a;
				e.at(-1)?.numeric !== o && e.push({
					index: t,
					numeric: o,
					places: []
				}), e.at(-1)?.places.push({
					character: n,
					key: c[t] ?? 0,
					motion: i.motion === "roll" && r ? "roll" : "reveal",
					sign: i.motion === "roll" && p.test(n) && f.test(g.value[t - 1] ?? "") !== f.test(g.value[t + 1] ?? "")
				});
			}
			return e;
		});
		return P(g, (e) => {
			for (let [t, n] of e.entries()) n !== u[t] && (c[t] = ++d);
			u = e;
		}, {
			immediate: !0,
			flush: "sync"
		}), (n, i) => (b(), a("span", Ue, [o("span", {
			class: "sy-visually-hidden",
			"aria-live": r.announce ? "polite" : void 0
		}, T(r.value), 9, We), o("span", Ge, [(b(!0), a(e, null, C(_.value, (n) => (b(), a("span", {
			key: n.index,
			class: "sy-motion-text__group",
			dir: n.numeric ? "ltr" : void 0
		}, [(b(!0), a(e, null, C(n.places, ({ character: e, key: n, motion: i, sign: o }, s) => (b(), a("span", {
			key: s,
			class: "sy-motion-text__place",
			"data-motion": i,
			"data-number-sign": o || void 0
		}, [l(t, {
			name: "sy-character",
			appear: r.appear
		}, {
			default: I(() => [(b(), a("span", {
				key: n,
				class: "sy-motion-text__glyph"
			}, T(e), 1))]),
			_: 2
		}, 1032, ["appear"])], 8, qe))), 128))], 8, Ke))), 128))])]));
	}
}), Ye = [
	"role",
	"aria-labelledby",
	"aria-valuenow",
	"aria-valuetext",
	"data-size",
	"data-tone",
	"data-indeterminate"
], Xe = {
	key: 0,
	class: "sy-measure__caption"
}, Ze = {
	key: 0,
	class: "sy-measure__value",
	"aria-hidden": "true"
}, Qe = /* @__PURE__ */ u({
	__name: "SLinearMeasurement",
	props: {
		value: {},
		min: {},
		max: {},
		label: {},
		locale: {},
		formatOptions: {},
		showValue: {
			type: Boolean,
			default: !0
		},
		size: { default: "md" },
		tone: { default: "accent" },
		role: {},
		indeterminate: { type: Boolean }
	},
	setup(e) {
		let t = e, r = `sy-measure-${O()}`, { value: s, display: u, bars: d, aria: f } = He(t, t.role === "progressbar", t.role === "progressbar"), p = n(() => t.role === "progressbar" && (t.indeterminate || s.value === void 0));
		return (t, n) => (b(), a("div", h({
			class: "sy-measure",
			role: e.role,
			"aria-labelledby": e.label || t.$slots.label ? r : void 0
		}, E(f), {
			"aria-valuenow": p.value ? void 0 : E(f)["aria-valuenow"],
			"aria-valuetext": p.value ? void 0 : E(f)["aria-valuetext"],
			"data-size": e.size,
			"data-tone": e.tone,
			"data-indeterminate": p.value || void 0,
			style: E(d)
		}), [e.label || t.$slots.label || e.showValue ? (b(), a("div", Xe, [o("span", { id: r }, [w(t.$slots, "label", {}, () => [c(T(e.label), 1)])]), e.showValue ? (b(), a("div", Ze, [w(t.$slots, "value", {
			text: E(u),
			value: E(s),
			indeterminate: p.value
		}, () => [l(Je, {
			value: p.value ? "\xA0" : E(u),
			motion: "roll"
		}, null, 8, ["value"])])])) : i("", !0)])) : i("", !0), n[0] ||= o("div", {
			class: "sy-measure__track",
			"aria-hidden": "true"
		}, [o("div", { class: "sy-measure__fill" })], -1)], 16, Ye));
	}
}), $e = /* @__PURE__ */ u({
	__name: "SProgressBar",
	props: {
		value: {},
		min: {},
		max: {},
		label: {},
		locale: {},
		formatOptions: {},
		showValue: {
			type: Boolean,
			default: !0
		},
		size: {},
		tone: {},
		indeterminate: { type: Boolean }
	},
	setup(e) {
		return (e, t) => (b(), r(Qe, h(e.$props, { role: "progressbar" }), s({ _: 2 }, [e.$slots.label ? {
			name: "label",
			fn: I(() => [w(e.$slots, "label")]),
			key: "0"
		} : void 0, e.$slots.value ? {
			name: "value",
			fn: I((t) => [w(e.$slots, "value", _(d(t)))]),
			key: "1"
		} : void 0]), 1040));
	}
}), et = [
	"data-size",
	"role",
	"aria-hidden"
], tt = {
	key: 0,
	class: "sy-visually-hidden"
}, nt = /* @__PURE__ */ u({
	__name: "SSpinner",
	props: {
		label: { default: "Loading" },
		size: { default: "md" },
		decorative: { type: Boolean }
	},
	setup(e) {
		return (t, n) => (b(), a("span", {
			class: "sy-spinner",
			"data-size": e.size,
			role: e.decorative ? void 0 : "status",
			"aria-hidden": e.decorative || void 0
		}, [n[0] ||= o("span", {
			class: "sy-spinner__ring",
			"aria-hidden": "true"
		}, null, -1), e.decorative ? i("", !0) : (b(), a("span", tt, T(e.label), 1))], 8, et));
	}
});
export { Pe as SAlert, Oe as SBadge, B as SButton, Ve as SCheckbox, Te as SDialog, pe as SInput, $e as SProgressBar, nt as SSpinner, ge as STextArea };
